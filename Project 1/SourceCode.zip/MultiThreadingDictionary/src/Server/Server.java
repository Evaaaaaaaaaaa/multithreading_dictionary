/**
 * Author: Keixn Wang
 * Student ID: 867024
 * */
package Server;

import java.awt.EventQueue;
import java.awt.Insets;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


import DictioanryRequest.ReadWriteFile;
import DictioanryRequest.RequestHandler;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JScrollPane;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Server
 * Launch the application.
 */
public class Server {
	//gui variable
	private JFrame frame;
	private static JTextArea textArea;
	//thread variable
	private static ThreadWorker[] threads;
	// clientQueue and number
	private static int clientNum = 0;
	private static LinkedBlockingQueue<ClientHandler> clientQueue;
	//thread pool size
	private static int threadSize = 3;
	// store command input port and dictioanry file path
	private static int portNum;
	private static String dicFile;
	// store dictionary datas
	private static ReadWriteFile dictData;
	private static ConcurrentHashMap<String, Object> conMap;
	public static void main(String[] args) {
		
		if (args.length!= 2){
			System.out.println("You should enter exact 2 command arguments: port number and dictionary file");
			System.exit(0);
		}
		// get command line input port number and dictionary file path
		try{
			portNum = Integer.parseInt(args[0]);
			dicFile = args[1];

		}catch(IllegalArgumentException e) {
			System.out.println("Command-line argumements in wrong format.");
			System.exit(0);
		}
		//read json dictionary data into map
		dictData = new ReadWriteFile(dicFile);
		conMap = dictData.convertToConMap();
		if (conMap == null) {
			System.out.println("Dictionary file not found, please double check and try again.");
			System.exit(0);
		}
		// creating the GUI
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Server window = new Server();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		

		ServerSocket listeningSocket = null;
		Socket clientSocket = null;
		clientQueue = new LinkedBlockingQueue<ClientHandler>();
		
		//Variable used to store all threads created
		threads = new ThreadWorker[threadSize];
		try {
			// creating fixed number of threads and start working(thread pool)
			for (int i = 0; i < threadSize; i++) {
				threads[i] = new ThreadWorker(clientQueue);
				threads[i].start();
				
			}
			//Create a server socket listening on given port
			listeningSocket = new ServerSocket(portNum);
			System.out.println("Server listening on port "+portNum+" for a connection");
			//Listen for incoming connections for ever 
			while (true) 
			{	
				//Accept an incoming client connection request
				//accept() method will block until a connection request is received
				clientSocket = listeningSocket.accept(); 
				clientNum++;
				
				System.out.println("Remote Hostname: " + clientSocket.getInetAddress().getHostName());
				System.out.println("Local Port: " + clientSocket.getLocalPort());
				// create clientHandler object
				ClientHandler clientH = new ClientHandler(clientSocket, clientNum, conMap, dictData);
				clientH.textArea = textArea;
				
				// add client into the queue and notify()
				synchronized (clientQueue) {
					clientQueue.add(clientH);
					clientQueue.notify();
		        }				
			}
		} 
		catch (SocketException ex)
		{
			ex.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		} 
		finally
		{
			if(listeningSocket != null)
			{
				try
				{
					RequestHandler requestH = new RequestHandler(conMap);
					dictData.writeToFile(requestH.getConMap());
					listeningSocket.close();
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		}
	}
	

	/**
	 * Create the application.
	 */
	public Server() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		// new frame
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.textHighlight);
		frame.getContentPane().setForeground(Color.GRAY);
		frame.setForeground(new Color(0, 0, 0));
		frame.setBounds(100, 100, 521, 305);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(dim.width/4-frame.getSize().width/2, dim.height/2-frame.getSize().height/2);
		// enable scroll bar
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setAutoscrolls(true);
		scrollPane.setBounds(0, 39, 521, 193);
		frame.getContentPane().add(scrollPane);
		// create textArea
		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setMargin(new Insets(15,15,15,15));
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);
		// when server side is closing the window, write memory into file first.
		frame.addWindowListener(new WindowAdapter() {
		     public void windowClosing(WindowEvent we) {
		    	 int result = JOptionPane.showConfirmDialog(frame,
		            "Do you want to close the server?", "Exit Confirmation : ",
		            JOptionPane.YES_NO_OPTION);
		        if (result == JOptionPane.YES_OPTION) {
		        	
		        	RequestHandler requestH = new RequestHandler(conMap);
					dictData.writeToFile(requestH.getConMap());
		        	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        
		        }
		        	
		          
		        else if (result == JOptionPane.NO_OPTION) {
		          frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		        }
		      }
		    });
	}

}
