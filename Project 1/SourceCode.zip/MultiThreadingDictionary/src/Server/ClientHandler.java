/**
 * Author: Keixn Wang
 * Student ID: 867024
 * */
package Server;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.JTextArea;

import DictioanryRequest.ReadWriteFile;
import DictioanryRequest.RequestHandler;

/*
 * Client handler created for each client connection
 * */
public class ClientHandler{
	private Socket clientS;
	private DataInputStream in;
	private DataOutputStream out;
	JTextArea textArea;
	private ReadWriteFile dictData;
	private RequestHandler requestH;
	private int num;
	public ClientHandler(Socket clientSocket, int clientNum, ConcurrentHashMap<String, Object> conMap, ReadWriteFile dictData) {
		this.clientS = clientSocket;
		this.num = clientNum;
		this.dictData = dictData;
		requestH = new RequestHandler(conMap);
		try {
			// Input stream
			in = new DataInputStream(clientS.getInputStream());
			// Output Stream
		    out = new DataOutputStream(clientS.getOutputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void run() {
		// TODO Auto-generated method stub
		textArea.setText(textArea.getText().trim()+"\nclient " + num + "is connected");
		// if client does not make request in 1 minute, connection will be cut
		try {
			clientS.setSoTimeout(60*1000);
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String clientMsg = null;
		try 
		{
			boolean firstRequest = false;
			// keep getting client request
			while((clientMsg = in.readUTF()) != null) 
			{	
				// maximum waiting time is 1 minute before cutting the connection
				try {
					clientS.setSoTimeout(60*1000);
				} catch (SocketException e1) {

					e1.printStackTrace();
				}
				
				// if it is the first request from current client, tell her she is connected
				if (firstRequest == false) {
					out.writeUTF("Hi, you are now connected.");
					
					firstRequest = true;
				}
				
				// display client request on the textArea
				textArea.setText(textArea.getText().trim()+"\nMessage from client " + num + ": " + clientMsg);
				textArea.setCaretPosition(textArea.getText().length());
				System.out.println("Message from client " + num + ": " + clientMsg);
				
				// distinguish client request
				// search a word
				if (clientMsg.contains("Search for\n")){
					// get the word and check for validation
					String word = clientMsg.substring(clientMsg.lastIndexOf("\n") + 1).toLowerCase();
					String checkWord = checkValidWord(word);
					// send response back to client
					if (checkWord != "Valid") {
						out.writeUTF(checkWord+"\n");
					}else {
						String meaning = requestH.getMeaning(word);
						if (meaning == "The word does not exsit in the dictionary.") {
							out.writeUTF(meaning);
						}else {
							out.writeUTF("meaning of "+ word + ": \n"+ meaning);
						}	
					}
				}
				
				// add a word
				else if(clientMsg.contains("Add a word\n")) {
					// extract word and meaning
					String word = clientMsg.substring(clientMsg.lastIndexOf("\n") + 1, clientMsg.indexOf(":")).toLowerCase();
					String meaning = clientMsg.substring(clientMsg.indexOf(":") +2);
					// get the result and send back to the client
					
					String checkWord = checkValidWord(word);
					String checkMeaning = checkValidMeaning(meaning);
					if (checkWord != "Valid") {
						out.writeUTF(checkWord+"\n");
					}else if(checkMeaning != "Valid") {
						out.writeUTF(checkMeaning+"\n");
					}
					else {
						String add = requestH.addWord(word, meaning);
					
						if (add == "Added") {
							out.writeUTF("word added:\n" + word + ": " + meaning);
						}else{
							out.writeUTF(add + "\n");

						}
				
					}
				}
				// delete a word
				else if(clientMsg.contains("Delete a word\n")) {
					String word = clientMsg.substring(clientMsg.lastIndexOf("\n") + 1).toLowerCase();
					// get the result and send back to the client
					String remove = requestH.deleteWord(word);
					if (remove == "Removed") {
						out.writeUTF("word removed:\n" + word + "\n");	
					}else{
						out.writeUTF(remove + "\n");
					}
				}
				System.out.println("Response sent");
			}
		}
		
		catch(SocketException e)
		{
			dictData.writeToFile(requestH.getConMap());
			System.out.println("closed...");
		} catch (IOException e) {
			// TODO Auto-generated catch bloc
			
			dictData.writeToFile(requestH.getConMap());
			textArea.setText(textArea.getText().trim()+"\n"+"Client "+num+" is disconnected");
			e.printStackTrace();
		}
		
		try {
			dictData.writeToFile(requestH.getConMap());
			clientS.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			dictData.writeToFile(requestH.getConMap());
			e.printStackTrace();
		}
	}
	
	// check if a word is valid
	private String checkValidWord(String word) {
		// word length need to be greater than 1
		if (word.length() < 2) {
			return "Word too short";
		}
		// word need to formed of specific chars
		else if(!word.matches("^([a-z][\\-]?)*[a-z]+$")) {
            return "It seems you entered an invalid word";
		}
		
		return "Valid";
	}
	private String checkValidMeaning(String meaning) {
		// word length need to be greater than 1
		if (meaning.length() < 1) {
			return "You cannot enter an empty meaning for the word";
		}else if(!meaning.matches("^[ A-Za-z,.!;()]+$")){
			return "It seems you entered an invalid meaning";
		}
		
		return "Valid";
	}

}
