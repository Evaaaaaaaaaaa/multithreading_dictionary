/**
 * Author: Keixn Wang
 * Student ID: 867024
 * */
package Server;
import java.util.LinkedList;
import java.util.Queue;

// thread object, the therad will start working by calling .start()
public class ThreadWorker extends Thread{
	private Queue<ClientHandler> clientQueue = new LinkedList<ClientHandler>();
	
	public ThreadWorker(Queue<ClientHandler> clientQueue) {
		// clientHandlerQueue 
		this.clientQueue = clientQueue;
	}
	
	
	// run when called by start()
	public void run() {
		
		ClientHandler clientH;
		//constantly check if there is a client need to be handled
		while(true) {
			//
			synchronized (clientQueue) {
				// wait when clientQueue is empty
				while (clientQueue.isEmpty()) {
			        try {
			        	clientQueue.wait();
			        } catch (InterruptedException e) {
			            System.out.println("An error occurred while queue is waiting: " + e.getMessage());
			        }
			    }
			    //dequeue, if there is available client, handle client
			    clientH = clientQueue.poll();
			}

			// after run, this worker will go back up to the loop and get the next client
			try {
				clientH.run();
			// If we don't catch RuntimeException,the pool could leak threads
			} catch (RuntimeException e) {
			    System.out.println("Thread pool is interrupted due to an issue: " + e.getMessage());
			}
			
		}
		
	}

}
