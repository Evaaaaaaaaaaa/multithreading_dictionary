/**
 * Author: Keixn Wang
 * Student ID: 867024
 * */
package DictioanryRequest;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;


// this class is used to read from and write to the dictionary file
public class ReadWriteFile {
	// server path through the Json file path when creating the object
	private String dicFilePath;;
	public ReadWriteFile(String dicFilePath){
		this.dicFilePath = dicFilePath;
	}
	
	// using ConcurrentHashMap structure to store the dictionary data
	public ConcurrentHashMap<String, Object> convertToConMap() {
		ConcurrentHashMap<String, Object> conMap = new ConcurrentHashMap<String,Object>();
		
		// read into map
		ObjectMapper mapper = new ObjectMapper();
        try {
 
            File jsonFile = new File(dicFilePath);
            conMap = mapper.readValue(jsonFile,
                    new TypeReference<ConcurrentHashMap<String, Object>>() {
                    });
        } catch (JsonGenerationException e) {
        	return null;
        } catch (JsonMappingException e) {
        	return null;
        } catch (IOException e) {
        	return null;
        }
		return conMap;
		
	}
	
	
	// write the data in concurrentHashMap to Json file, this function is called when client is unconnected.
	public void writeToFile(ConcurrentHashMap<String, Object> conMap) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.writeValue(new File(dicFilePath), conMap);
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
}
