/**
 * Author: Keixn Wang
 * Student ID: 867024
 * */
package DictioanryRequest;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Request Handler, which used to access info / modify data in the memory, 
 * given request word/meaning 
 **/
public class RequestHandler {
	// store the concurrent hash map of the dictionary
	private ConcurrentHashMap<String, Object> conMap = new ConcurrentHashMap<String,Object>();
	public RequestHandler(ConcurrentHashMap<String, Object> conMap) {
		this.conMap = conMap;
	}
	
	// search a meaning of the word
	public String getMeaning(String word) {
		String meaning = (String) conMap.get(word);
		if (meaning != null) {
			return meaning; 
		}
		return "The word does not exsit in the dictionary.";
	}
	
	// add a word and its meaning to the map
	public String addWord(String word, String meaning) {
		String value = (String) conMap.get(word);
		if (value == null) {
			conMap.put(word,meaning);
			return "Added";
		}	
		return "The word already exsit in the dictioanry.";	
	}
	
	// delete a word in the map if it exist
	public String deleteWord(String word) {
		String value = (String) conMap.get(word);
		if (value != null) {
			conMap.remove(word);
			return "Removed";
		}
		return "The word does not exist in the dictionary.";
	}
	
	// get current dcit map
	public ConcurrentHashMap<String, Object> getConMap() {
		return conMap;
	}
}
