/**
 * Author: Keixn Wang
 * Student ID: 867024
 * */

package Client;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Insets;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *Client, connect to socket on given IP and port number 
 **/
public class Client {
	//gui variables
	private JFrame frame;
	private static JTextArea textArea;
	private JTextField textField;
	private static JLabel status;
	private JTextField meaningField;
	// in and out stream
	private static DataInputStream in;
	private static DataOutputStream out;
	// command line input IP and port
	private static String IP;
	private static int portNum;
	private static Client window;
	private static boolean firstRequest = true;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		
		// get ip and port which client wants to connect to from client input
	
		if (args.length!= 2){
			System.out.println("You should enter exact 2 command arguments: server-IP and port");
			System.exit(0);
		}
		try{
			IP = args[0];
			portNum = Integer.parseInt(args[1]);
				
		}catch(IllegalArgumentException e) {
			System.out.println("Command-line argumements in wrong format.");
			System.exit(0);
		}	
		firstRequest = true;
		Socket socket = null;
		
		try {
	        if (!InetAddress.getByName(IP).isReachable(5000)) {
	            System.err.println(IP+" Address is not reachable, unknown host.");
	            System.exit(0);
	        }
	    } catch (UnknownHostException e) {
	        System.err.println(IP+" Address is not reachable, unknown host.");
	        System.exit(0);
	    } catch (IOException e) {
	        System.err.println(IP+" throws IOException, plese double check and try again");
	        System.exit(0);
	    }
		
		try 
		{
			// Create a stream socket bounded to any port and connect it to the
			// socket bound to localhost on port 4444
			
			socket = new Socket(IP, portNum);
			// if client does not make request in 15s, connection will be cut
			System.out.println("Connection established");
			// Launch gui 
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						window = new Client();
						window.frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});

			// Get the input/output streams for reading/writing data from/to the socket
			// Input stream
			in = new DataInputStream(socket.getInputStream());
			// Output Stream
		    out = new DataOutputStream(socket.getOutputStream());

		    // keep reading servers responds
			String inputStr = null;
			while((inputStr = in.readUTF()) != null) 
			{	
				// first responds, telling client is connected, change status on gui
				if (inputStr.equals("Hi, you are now connected.")) {
					status.setText(inputStr);
					ImageIcon imageIcon = new ImageIcon(new ImageIcon("green.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
					status.setIcon(imageIcon);
				}else {
					// display input on the textArea, using if else to adjust the display format
					if (textArea.getText().length() == 0) {
						textArea.setText(textArea.getText().trim()+inputStr+"\n");
						
					}else {
						textArea.setText(textArea.getText().trim()+"\n\n"+inputStr+"\n\n");
					}
					// textArea always truck the newest message
					textArea.setCaretPosition(textArea.getText().length());
			
				}
			}
			
		} 
		catch (UnknownHostException e)
		{
			
			// display error message and close frame
			JOptionPane.showMessageDialog(null,"Connection error, double check and try again later.");
			e.printStackTrace();
			window.frame.dispose();

		}
		catch (IOException e)
		{
			// display error message and close frame
			JOptionPane.showMessageDialog(null,"Connection error, double check and try again later.");
			e.printStackTrace();
			window.frame.dispose();
			
		} 
		finally
		{
			// Close the socket
			if (socket != null)
			{
				try
				{
					System.out.println("dasdsadas");
					socket.close();
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Create the application.
	 */
	public Client() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		// create frame
		frame = new JFrame();
		frame.setBackground(new Color(255, 255, 255));
		frame.setForeground(SystemColor.window);
		frame.getContentPane().setBackground(new Color(25, 25, 112));
		frame.setBounds(50, 100, 672, 413);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setFocusable(true);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(dim.width/2, dim.height/2-frame.getSize().height/2);
		//create textField
		textField = new JTextField();
		textField.setForeground(Color.GRAY);
		textField.setCaretColor(new Color(192, 192, 192));
		textField.setText("Enter a word to search");
		textField.setBounds(39, 57, 188, 41);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		// search button
		JRadioButton searchButton = new JRadioButton("Search");
		searchButton.setForeground(new Color(255, 255, 255));
		searchButton.setSelected(true);
		searchButton.setBounds(29, 22, 77, 23);
		frame.getContentPane().add(searchButton);
		searchButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				textField.setText("");
				textField.setText("Enter a word to search");
				textField.setForeground(Color.GRAY);
				meaningField.setVisible(false);
			}
		});
		
		
		// add button
		JRadioButton addButton = new JRadioButton("Add");
		addButton.setForeground(new Color(255, 255, 255));
		addButton.setBounds(118, 22, 77, 23);
		frame.getContentPane().add(addButton);
		addButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				textField.selectAll();
				textField.setText("Enter a word to add");
				textField.setForeground(Color.GRAY);
				meaningField.setVisible(true);
				meaningField.setText("Enter the meaning");
				meaningField.setForeground(Color.GRAY);
				
			}
		});
		
		// delete button
		JRadioButton deleteButton = new JRadioButton("Delete");
		deleteButton.setForeground(new Color(255, 255, 255));
		deleteButton.setBounds(199, 22, 77, 23);
		frame.getContentPane().add(deleteButton);
		deleteButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				textField.selectAll();
				textField.setText("Enter a word to delete");
				textField.setForeground(Color.GRAY);
				meaningField.setVisible(false);
			}
		});
		
		// group three buttons together,so only one button can be clicked at the moment
		ButtonGroup group = new ButtonGroup();
		group.add(searchButton);
		group.add(addButton);
		group.add(deleteButton);
		
		// adding scroll bar
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setAutoscrolls(true);
		scrollPane.setBounds(0, 120, 672, 239);
		frame.getContentPane().add(scrollPane);
		
		// text area
		textArea = new JTextArea(10,20);
		textArea.setName("textArea");
		textArea.setSelectionColor(new Color(192, 192, 192));
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);
		textArea.setLineWrap(true);
		textArea.setColumns(10);
		textArea.setRows(20);
		textArea.setTabSize(4);
		textArea.setMargin( new Insets(15,15,15,15));
		textArea.setWrapStyleWord(true);
		textArea.setCaretPosition(textArea.getDocument().getLength());
		

		// meaning field for add item function
		meaningField = new JTextField();
		meaningField.setText("Enter the meaning");
		meaningField.setVisible(false);
		meaningField.setForeground(Color.GRAY);
		meaningField.setColumns(10);
		meaningField.setCaretColor(Color.LIGHT_GRAY);
		meaningField.setBounds(263, 57, 372, 41);
		frame.getContentPane().add(meaningField);
		// set focus listener for meaning field
		meaningField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (meaningField.getForeground() == Color.GRAY) {
					meaningField.setText("");
					meaningField.setForeground(new Color(0, 0, 0));
				}
				
		
			}
			public void focusLost(FocusEvent e) {
				if (addButton.isSelected() && meaningField.getText().length() == 0) {
					meaningField.setText("Enter the meaning");
					meaningField.setForeground(Color.GRAY);
				}
				
				
			}
			
		});
		// set key listener for meaning field, add word when "enter" is pressed
		meaningField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				String word = "";
				String meaning = "";
				word = textField.getText().trim();
				meaning = meaningField.getText().trim();
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					try {
						// client in line to be served
						if (firstRequest == true && word != "" && meaning != "") {
							status.setText("you are in line to be connected");
							ImageIcon imageIcon = new ImageIcon(new ImageIcon("green.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
							status.setIcon(imageIcon);
							status.setIcon(imageIcon);
							firstRequest = false;	
						}
						// write request to server
						out.writeUTF("\nAdd a word\n"+word+": "+meaning);


					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		
		//create status label, which shows the current status of the client (connected or not)
		status = new JLabel("SEND YOUR REQUEST");
		ImageIcon imageIcon = new ImageIcon(new ImageIcon("search.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
		status.setIcon(imageIcon);
		status.setForeground(Color.WHITE);
		status.setBounds(378, 20, 242, 29);
		frame.getContentPane().add(status);
	
		// text filed add focus listener, set placeholder
		textField.addFocusListener(new FocusAdapter() {
			
			@Override
			public void focusGained(FocusEvent e) {
				
				if (textField.getForeground() == Color.GRAY) {
					textField.setText("");
					textField.setForeground(new Color(0, 0, 0));
				}
			}
			public void focusLost(FocusEvent e) {
				if (searchButton.isSelected() && textField.getText().length() == 0) {
					textField.setText("Enter a word to search");
					textField.setForeground(Color.GRAY);	
										
				}
				else if (addButton.isSelected() && textField.getText().length() == 0) {
					textField.setText("Enter a word to add");
					textField.setForeground(Color.GRAY);	
				}
				else if (deleteButton.isSelected() && textField.getText().length() == 0) {
					textField.setText("Enter a word to delete");
					textField.setForeground(Color.GRAY);	
				}			
			}	
		}
		);
		
		// text field enter key listener
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					// client in line to be served
					if (firstRequest == true && !addButton.isSelected()) {
						status.setText("you are in line to be connected");
						ImageIcon imageIcon = new ImageIcon(new ImageIcon("red.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
						status.setIcon(imageIcon);
						firstRequest = false;	
					}
					// write request to server
					try {
						String outStr = "";
						outStr = textField.getText().trim();
						if (searchButton.isSelected()) {
							out.writeUTF("\nSearch for\n"+outStr);
						}else if (addButton.isSelected()) {
							if (textField.getText()!="") {
								meaningField.requestFocus();
							}
						}else if (deleteButton.isSelected()) {
							out.writeUTF("\nDelete a word\n"+outStr);
						}
						// select words in the text area for user eaier to delete
						textField.selectAll();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		frame.addWindowListener(new WindowAdapter() {
		     public void windowClosing(WindowEvent we) {
		    	 int result = JOptionPane.showConfirmDialog(frame,
		            "Do you want to Exit ?", "Exit Confirmation : ",
		            JOptionPane.YES_NO_OPTION);
		        if (result == JOptionPane.YES_OPTION) {
		        	try {
		        		  if(null != in) {
		        		    in.close();
		        		  }
		        		} catch(IOException ex) {
		        		  // Log or ignore the exception.
		        	}
		        	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        
		        }
		        	
		          
		        else if (result == JOptionPane.NO_OPTION) {
		          frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		        }
		      }
		    });
		
	}
}
